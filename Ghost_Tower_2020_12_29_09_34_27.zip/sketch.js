var tower, towerImage;
var door, doorImage;
var doorGroup;
var climber,climberImage;
var climberGroup;
var ghost, ghostImage;
var invisibleblock, invisibleblockGroup;
var gameState = "play";
var ghostSound;

function preload() {
  towerImage = loadImage("tower.png");
  doorImage = loadImage("door.png");
  climberImage = loadImage("climber.png");
  ghostImage = loadImage("ghost-standing.png")
  ghostSound = loadSound("spooky.wav")
}

function setup() {
  createCanvas(600, 600);

  ghostSound.loop();
  
  tower = createSprite(300, 300);
  tower.addImage(towerImage);
  tower.velocityY = 3;
  
  ghost = createSprite(200,200);
  ghost.addImage(ghostImage);
ghost.scale = 0.3;
  
  doorGroup = new Group();
  climberGroup = new Group();
  invisibleblockGroup = new Group();
}

function draw() {
  background("white");
  
  if (gameState==="play"){
if (tower.y > 400) {
    tower.y = 300;
  }

  if(keyDown("left_arrow")){
    ghost.x = ghost.x-3;
  }
  if(keyDown("right_arrow")){
    ghost.x = ghost.x+3;
  }
  if(keyDown("space")){
   ghost.velocityY = -3; 
  }
    ghost.velocityY = ghost.velocityY+0.8;

  if (climberGroup.isTouching(ghost)){
    ghost.velocityY=0;
  }
  
if(invisibleblockGroup.isTouching(ghost)||ghost.y>600){
  
  ghost.destroy();
  tower.destroy();
  
  gameState = "end"
    
  }
 
  spawnDoors();
  }
  
if (gameState === "end"){
 stroke("yellow");
 fill("yellow");
 textSize(30);
 text("Game Over", 230,250)
 }
  drawSprites();
}

function spawnDoors() {

  if (frameCount % 200 === 0) {
    door = createSprite(200, -50);
    door.addImage(doorImage);
    door.x = Math.round(random(120, 400));
    door.velocityY = 3;
    climber = createSprite(200,10);
    climber.addImage(climberImage);
    climber.x = door.x;
    climber.velocityY = 3;
    invisibleblock = createSprite(200,15);
    invisibleblock.width = climber.width;
    invisibleblock.height = 2;
    invisibleblock.x = door.x;
    invisibleblock.velocityY=3;
    invisibleblock.visible = false;
    door.lifetime = 100;
    climber.lifetime = 100;
    climberGroup.add(climber);
    doorGroup.add(door);
    invisibleblockGroup.add(invisibleblock);
    ghost.depth = door.depth;
    ghost.depth = ghost.depth+1;
  }
}